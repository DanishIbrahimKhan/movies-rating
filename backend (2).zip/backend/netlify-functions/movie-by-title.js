const axios = require('axios');

const OMDB_API_KEY = '3aa28eff';
const OMDB_BASE_URL = 'http://www.omdbapi.com/';

exports.handler = async (event, context) => {
  const { t } = event.pathParameters;  // Extract movie title from URL params

  try {
    const response = await axios.get(`${OMDB_BASE_URL}?t=${t}&apikey=${OMDB_API_KEY}`);
    
    if (response.data.Response === 'True') {
      return {
        statusCode: 200,
        body: JSON.stringify(response.data),
      };
    } else {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: response.data.Error }),
      };
    }
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    };
  }
};

// Home page route
exports.handlerHome = async () => {
  return {
    statusCode: 200,
    body: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Serverless Movie API</title>
      </head>
      <body>
        <h1>Welcome to the Serverless Movie API</h1>
        <p>Use the endpoint <code>/movie-by-title/{movie-name}</code> to search for a movie.</p>
        <script>
          // JavaScript code to trigger alert or log to the console when the homepage is accessed
          alert("Welcome to the Serverless Movie API!");
          // or log to the browser console
          console.log("Serverless Movie API homepage loaded!");
        </script>
      </body>
      </html>
    `,
  };
};
